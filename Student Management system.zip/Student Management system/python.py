dict={"id":1,"name":"abhishek"}
print(dict["name"])